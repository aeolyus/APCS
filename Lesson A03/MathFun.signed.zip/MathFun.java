/** 
 * 
 * @author Richard Huang
 * Period #1
 *
 */



public class MathFun {
	
	public void calculate(){
		int answer1 = 4 + 9;
		System.out.println("4 + 9 = " + answer1);
		
		int answer2 = 46/7;
		System.out.println("46 / 7 = " + answer2);
		
		int answer3 = 46%7;
		System.out.println("46 % 7 = " + answer3);
		
		double answer4 =2*3.0;
		System.out.println("2 * 3.0 = " + answer4);
		
		double answer5 = (double)25/4;
		System.out.println("(double)25 / 4 = " + answer5);
		
		int answer6 = (int)7.75+2;
		System.out.println("(int)7.75 + 2 = " + answer6);
		
		int answer7 = (int)'P';
		System.out.println("(int)'P' = " + answer7);
		
		char answer8 = (char)105;
		System.out.println("(char)105 = " + answer8);
	}

}
