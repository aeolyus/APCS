/**
 * @author Richard Huang
 * period 1
 */
public interface Measurable{
    //returns the perimeter
    public double getPerimeter();
    //returns the area
    public double getArea();
    //returns the dimensions
    public String toString();
}