public class GCFAndLCMDriver {
	public static void main(String[] args) {
		int a =       3; 
		int b =       5; 
		System.out.println("GCF of " + a + " and " + b + " is: " + GCFAndLCM.GCF(a, b));
		int x =       100; 
		int y =       5; 
		System.out.println("LCM of " + x + " and " + y + " is: " + GCFAndLCM.LCM(x, y));
		
	}	
}